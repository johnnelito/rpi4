#!/bin/sh



WRAPn="$0"
bNAME="$(basename $0)"

SHUTscr="/etc/custom/shutdown.sh"




DEBUG=1
[ -n "$DEBUG" ] && RCSLEEP=1



eKO() {
	#[ -n "$DEBUG" ] && echo "$bNAME ${*}"
	[ -n "$DEBUG" ] && echo "consoleonly-$bNAME ${*}" > /dev/console
}



#@@@ case what we were called as...
case "$bNAME" in
    reboot)
        :
    ;;
    halt)
        :
    ;;

    *)
        eKO "OOOOOOOOOOOOOOOOOOOOOOOO: $0 ${*}"; sleep 7
    ;;
esac






#eKO "PAYLOADCMD(early): /bin/busybox ${bNAME} ${@}"; sleep ${RCSLEEP:-0}



if [ -f "$SHUTscr" ]; then

    eKO "RUNNING: $SHUTscr plog"
    $SHUTscr plog

    eKO "RUNNING: $SHUTscr shutdown"
	$SHUTscr shutdown

else

    if [ "$(pwd)" = "/tmp/root" ]; then
        : #called from sysupgrade end
        eKO ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> all done"
    else
        #notDEBUG@eKO
        eKO "pre-shutdown: $SHUTscr [missing]"; sleep ${RCSLEEP:-0}
    fi

fi
sleep ${RCSLEEP:-0}


/bin/busybox ${bNAME} ${@}


eKO "done -> test-exit0" ###NEVERREACHHERE
sleep 2 #dbgslpforce
exit 0











