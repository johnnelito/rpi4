#!/bin/sh
#FORCOLOR



. /lib/functions.sh

REQUIRE_IMAGE_METADATA=1




# copied from x86's platform.sh








platform_check_image() {
	local diskdev partdev diff

	[ "$#" -gt 1 ] && return 1

	export_bootdevice && export_partdevice diskdev 0 || {
		echo "Unable to determine upgrade device"
		return 1
	}

	get_partitions "/dev/$diskdev" bootdisk

	#extract the boot sector from the image
	get_image "$@" | dd of=/tmp/image.bs count=1 bs=512b 2>/dev/null

	get_partitions /tmp/image.bs image

	#compare tables
	diff="$(grep -F -x -v -f /tmp/partmap.bootdisk /tmp/partmap.image)"

	rm -f /tmp/image.bs /tmp/partmap.bootdisk /tmp/partmap.image

	if [ -n "$diff" ]; then
		echo "Partition layout has changed. Full image will be written."
		ask_bool 0 "Abort" && exit 1
		return 0
	fi

	return 0;
}














platform_do_upgrade() {

	local diskdev partdev diff

	export_bootdevice && export_partdevice diskdev 0 || {
		echo "Unable to determine upgrade device"
		return 1
	}

	sync

	if [ "$UPGRADE_OPT_SAVE_PARTITIONS" = "1" ]; then
		get_partitions "/dev/$diskdev" bootdisk

		#extract the boot sector from the image
		get_image "$@" | dd of=/tmp/image.bs count=1 bs=512b

		get_partitions /tmp/image.bs image

		#compare tables
		diff="$(grep -F -x -v -f /tmp/partmap.bootdisk /tmp/partmap.image)"
	else
		diff=1
	fi


    #NOTE dontthinkthisisthactivefunctionITISbutthisdidnrprint must be dev console thing???
    #local DEBUGDISKWRITE=1
	if [ -n "$diff" ]; then



        get_image "$@" | dd of="/dev/$diskdev" bs=2M conv=fsync


		# Separate removal and addtion is necessary; otherwise, partition 1
		# will be missing if it overlaps with the old partition 2
		partx -d - "/dev/$diskdev"
		partx -a - "/dev/$diskdev"

		return 0
	fi





    #if [ ! -z "$DEBUGDISKWRITE" ]; then
	#    while read part start size; do
	#	    	echo "DBG Writing image to /dev/$partdev... partition:$part start:$start size:$size"
    #    done < /tmp/partmap.image
    #fi




	#iterate over each partition from the image and write it to the boot disk
	while read part start size; do
		echo "partition:$part start:$start size:$size"
		if export_partdevice partdev $part; then

			#ORIGINAL echo "Writing image to /dev/$partdev..."
			echo "Writing image-partition:$part to /dev/$partdev..."

            get_image "$@" | dd of="/dev/$partdev" ibs="512" obs=1M skip="$start" count="$size" conv=fsync

        else
			#ORIGINAL echo "Unable to find partition $part device, skipped."
			echo "Unable to find partition $part device, skipped."
	fi
	done < /tmp/partmap.image








    get_image "$@" | dd of="/tmp/faketable" bs=2M conv=fsync 2>/dev/null

    NEWUUID=$(partx -g -o UUID "/tmp/faketable" | dd bs=1 count=8 2>/dev/null)
    OLDUUID=$(partx -g -o UUID "/dev/$diskdev" 2>/dev/null | dd bs=1 count=8 2>/dev/null)


    OLDUUIDASCII=$(dd if=/dev/$diskdev bs=1 skip=440 count=4 2>/dev/null)
    NEWUUIDASCII=$(dd if=/tmp/faketable bs=1 skip=440 count=4 2>/dev/null)


    echo "Writing new UUID:${NEWUUID}:${NEWUUIDASCII} to /dev/$diskdev... [${OLDUUIDASCII}:${OLDUUID}]"

    get_image "$@" | dd of="/dev/$diskdev" bs=1 skip=440 count=4 seek=440 conv=fsync


}






















platform_copy_config() {


	local FN="platform_copy_config"



	if type platform_copy_confignice 2>/dev/null 1>/dev/null; then
        echo "$FN> CONSOLE using> platform_copy_confignice include@rpi4.sh" > /dev/console
        platform_copy_confignice
		return 0
	fi




	local partdev

	if export_partdevice partdev 1; then

		[ -n "$DEBUG" ] && vplat "$FN> partdev: /dev/$partdev"

		mkdir -p /boot
		[ -f /boot/kernel.img ] || mount -t vfat -o rw,noatime "/dev/$partdev" /boot

		cp -af "$UPGRADE_BACKUP" "/boot/$BACKUP_FILE"

        	echo "$FN> workaround @ true" > /dev/console
        	tar -C / -zxvf "$UPGRADE_BACKUP" boot/cmdline.txt boot/config.txt || true

		sync
		umount /boot
	fi


}





















#NEWUUID=$(get_image "$@" | dd bs=1 skip=440 count=4 seek=440 conv=fsync)
# dd if=rpiresignedtest1.img bs=1 skip=440 count=4
#OWRT                   4+0 records in
#zcat ../rpiresignedtest1.img.gz | dd bs=1 skip=440 count=4 2>/dev/null


#cat /dev/mmcblk0 | dd bs=1 skip=440 count=4 2>/dev/null #OWRT
#/dev/mmcblk0p1: SEC_TYPE="msdos" LABEL_FATBOOT="boot" LABEL="boot" UUID="6633-B334" BLOCK_SIZE="512" TYPE="vfat" PARTUUID="5452574f-01"

#blkid /dev/sda1 -s UUID -o value
#blkid /dev/mmcbl*
#echo -n OWRT | hexdump -C #reverse
#echo -n OWRT | hexdump -c #fromddback
#xxd -r <<<'0 4a'



#part1 echo -n OWRT | hexdump -v | head -n1 | cut -d" " -f2
#part2 echo -n OWRT | hexdump -v | head -n1 | cut -d" " -f2
#NEWUUID=${NEWUUIDp1}${NEWUUIDp2}

#NEWUUIDp1=$(get_image "$@" | dd bs=1 skip=440 count=4 2>/dev/null | hexdump -v | head -n1 | cut -d" " -f2)
#NEWUUIDp2=$(get_image "$@" | dd bs=1 skip=440 count=4 2>/dev/null | hexdump -v | head -n1 | cut -d" " -f1)
#NEWUUID=${NEWUUIDp1}${NEWUUIDp2}




#OLDUUIDASCII=$(get_image "$@" | dd bs=1 skip=440 count=4 2>/dev/null | hexdump -v | head -n1 | cut -d" " -f2)







#    local NEWUUIDASCII NEWUUIDp1 NEWUUIDp2 NEWUUID
#    NEWUUIDASCII=$(get_image "$@" | dd bs=1 skip=440 count=4 2>/dev/null | hexdump -v | head -n1 | cut -d" " -f2)
#    NEWUUIDp1=$(echo -n -e "${NEWUUIDASCII}" | hexdump -v | head -n1 | cut -d" " -f2)
#    NEWUUIDp2=$(echo -n -e "${NEWUUIDASCII}" | hexdump -v | head -n1 | cut -d" " -f1)
#    NEWUUID=${NEWUUIDp1}${NEWUUIDp2}

#    local OLDUUIDASCII OLDUUIDp1 OLDUUIDp2 OLDUUID
#    OLDUUIDASCII=$(dd if="/dev/$diskdev" bs=1 skip=440 count=4 2>/dev/null | hexdump -v | head -n1 | cut -d" " -f2)
#    OLDUUIDp1=$(echo -n -e "${OLDUUIDASCII}" | hexdump -v | head -n1 | cut -d" " -f2)
#    OLDUUIDp2=$(echo -n -e "${OLDUUIDASCII}" | hexdump -v | head -n1 | cut -d" " -f1)
#    OLDUUID=${NEWUUIDp1}${NEWUUIDp2}

#echo "Writing new UUID:${NEWUUID}:${NEWUUIDASCII} to /dev/$diskdev... [${OLDUUIDASCII}:$OLDUUID]"
###################################################################################################################



#partx -g -o UUID /usbstick/_BROKESYSUPCOPIES/openwrt-bcm27xx-bcm2711-rpi-4-squashfs-sysupgrade.img 2>/dev/null | tr -s '\n' ' ' | cut -c1-8


    ######################################################################################### HEAD NOT FOUND

    #local NEWUUIDASCII NEWUUIDp1 NEWUUIDp2 NEWUUID
    #NEWUUIDASCII=$(get_image "$@" | dd bs=1 skip=440 count=4 2>/dev/null | hexdump -v | head -n1 | cut -d" " -f2)
    #NEWUUIDp1=$(echo -n -e "${NEWUUIDASCII}" | hexdump -v | head -n1 | cut -d" " -f2)
    #NEWUUIDp2=$(echo -n -e "${NEWUUIDASCII}" | hexdump -v | head -n1 | cut -d" " -f1)
    #NEWUUID=${NEWUUIDp1}${NEWUUIDp2}

    #local OLDUUIDASCII OLDUUIDp1 OLDUUIDp2 OLDUUID
    #OLDUUIDASCII=$(dd if="/dev/$diskdev" bs=1 skip=440 count=4 2>/dev/null | hexdump -v | head -n1 | cut -d" " -f2)
    #OLDUUIDp1=$(echo -n -e "${OLDUUIDASCII}" | hexdump -v | head -n1 | cut -d" " -f2)
    #OLDUUIDp2=$(echo -n -e "${OLDUUIDASCII}" | hexdump -v | head -n1 | cut -d" " -f1)
    #OLDUUID=${NEWUUIDp1}${NEWUUIDp2}

    ######################################################################################### tr not available
    #OLDUUID=$(partx -g -o UUID "/dev/$diskdev" 2>/dev/null | tr -s '\n' ' ' | cut -c1-8)
    #NEWUUID=$(partx -g -o UUID "$@" 2>/dev/null | tr -s '\n' ' ' | cut -c1-8)

    #NEWUUID=$(partx -g -o UUID "$0" | dd bs=1 count=8 2>/dev/null)
    #OLDUUID=$(partx -g -o UUID "/dev/$diskdev" 2>/dev/null | dd bs=1 count=8 2>/dev/null)




############################################### no console use v or echo
#        if [ ! -z "$DEBUGDISKWRITE" ]; then
#            echo "DBGISDIFF ###################################################3# START" >/dev/console
#            echo "DBGISDIFF grep -F -x -v -f /tmp/partmap.bootdisk /tmp/partmap.image" >/dev/console
#            echo "DBGISDIFF ####################### diff" >/dev/console
#            echo "$diff" >/dev/console 2>/dev/null
#            echo "DBGISDIFF ################################# /tmp/partmap.image"
#            cat tmp/partmap.image > /dev/console 2>/dev/null
#            echo "DBGISDIFF ################################# /tmp/partmap.bootdisk"
#            cat tmp/partmap.bootdisk > /dev/console 2>/dev/null
#            echo "DBGISDIFF ###################################################3# END" >/dev/console
#        fi
###############################################







#get_image "$@" | dd of="/tmp/faketable" bs=2M conv=fsync 2>/dev/null
#NEWUUID=$(partx -g -o UUID "/tmp/faketable" | dd bs=1 count=8 2>/dev/null)
#OLDUUID=$(partx -g -o UUID "/dev/$diskdev" 2>/dev/null | dd bs=1 count=8 2>/dev/null)
#echo "Writing new UUID:${NEWUUID}:${NEWUUIDASCII} to /dev/$diskdev... [${OLDUUIDASCII}:${OLDUUID}]"



###########################################################################
#[root@dca632 /usbstick 49°]# platform.sh> ppidcmdline: /bin/bash
#platform.sh> $$cmdline: /bin/sh./master-autosysup-2021-Zzz-Zzz
#platform.sh> UPGSTAGE: ISLUCI: ISUSER: ISTMP:
#platform.sh> ppidcmdline: /bin/bash
#platform.sh> $$cmdline: /bin/sh./master-autosysup-2021-Zzz-Zzz
#platform.sh> UPGSTAGE: ISLUCI: ISUSER: ISTMP:
##########################################################################





#platform.sh> $$cmdline: /bin/sh./master-autosysup-2021-Zzz-Zzz
#platform.sh> UPGSTAGE: ISLUCI: ISUSER: ISTMP:




#NEWUUIDASCII=$(get_image "$@" | dd if=/dev/$diskdev bs=1 skip=440 count=4 2>/dev/null)
#NEWUUIDASCIIftable=$(dd if=/tmp/faketable bs=1 skip=440 count=4 2>/dev/null)
#echo "NEWASCIIftable: ${NEWUUIDASCIIftable}"


#NEWUUIDASCII=$(dd if=/dev/$diskdev bs=1 skip=440 count=4 2>/dev/null)
#"/tmp/faketable" | dd bs=1 count=8 2>/dev/null)
#echo "Writing new UUID:${NEWUUID} to /dev/$diskdev... [${OLDUUID}]"
#copy partition uuid #ORG echo "Writing new UUID to /dev/$diskdev... "
#######echo "Writing new UUID:${NEWUUID}:${NEWUUIDASCII} to /dev/$diskdev... [${OLDUUIDASCII}:${OLDUUID}]"
#echo "Writing new UUID:${NEWUUID} to /dev/$diskdev... [${OLDUUID}]"

#NEWUUID=$(partx -g -o UUID "$0" | dd bs=1 count=8 2>/dev/null)
#OLDUUID=$(partx -g -o UUID "/dev/$diskdev" 2>/dev/null | dd bs=1 count=8 2>/dev/null)












