

if [ -f /bin/updatecheck.sh ]; then
    /bin/updatecheck.sh
fi



