#!/bin/sh
ecmd="echo "
i=$(basename $0)
if [ -x /etc/custom/custfunc.sh ]; then
	. /etc/custom/custfunc.sh
	ecmd="echm ${i} "
fi



ffdir="/root"





now=$(printf "%d" $(date +%H%M))
today="`date +%Y%m%d`"
Dd="`date +%d`"
DH="`date +%H`"
DM="`date +%M`"
fD="/tmp"
fP="/tmp/`basename $0`"; mkdir -p $fP #or dont have slash

taskD="/root/tasks"
taskDdaily="$taskD/daily"
taskDhourly="$taskD/hourly"

DF="`date +%Y%m%d-%H%M`" #date full





###########################################################################
#### and files in /etc/cron.d. These files also have username fields,
#### that none of the other crontabs do.

#SHELL=/bin/sh
#PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin

# m h dom mon dow usercommand
#17 ** * *root    cd / && run-           parts --report /etc/cron.hourly
#25 6* * *if [ $(id -u) -ne 0 ]; then exec sudo $0; fitest -x /usr/sbin/anacr        on || ( cd / && run-parts --report /etc/cron.daily  )
#47 6* * 7rootte         st -x /usr/sbin/anacron || ( cd / && run-parts --report /etc/cron.weekly  )
#52 61 * *if [ $(id -u) -ne 0 ]; then exec sudo $0; fitest -x /usr/sbin/anacron || ( cd / && run-parts --r       eport /etc/cron.monthly  )
###########################################################################













#17 ** * *
#root    cd / && run-           parts --report /etc/cron.hourly


#25 6* * *
#if [ $(id -u) -ne 0 ]; then exec sudo $0; fitest -x /usr/sbin/anacr        on || ( cd / && run-parts --report /etc/cron.daily  )

#47 6* * 7
#rootte         st -x /usr/sbin/anacron || ( cd / && run-parts --report /etc/cron.weekly  )

#52 61 * *
#if [ $(id -u) -ne 0 ]; then exec sudo $0; fitest -x /usr/sbin/anacron || ( cd / && run-parts --r       eport /etc/cron.monthly  )
###########################################################################












isok() {

FN="isok"; #ecmd "$FN ${*}" 2 5


if [ -z "$1" ]; then $ecmd "param 1 [missing]" && return 1; fi
if [ -z "$1" ]; then $ecmd "param 2 [missing]" && return 1; fi

#$ecmd "$FN: ${*}"; sleep 2

case "$1" in
	link)
		:
	;;
	file)
		:
	;;
	ff)
		if [ ! -f "$2" ]; then
            return 1
        else
            return 0
        fi
	;;
	dir) if [ ! -d "$2" ]; then return 1; fi; ;;
	*)
		echo "$FN invalid case $1"; return 1
	;;
esac



return 0
}







if [ -z "$1" ]; then
    sACTION="init"
fi





DSi=$(date +%Y%m%d%H%M)
logF="/restorefiles/tasks/logs/$(basename $0)_${DSi}.log"



$ecmd "init actions:${*} $logF"; sleep 2



iM="$(basename $0)"
ffpfx="$ffdir/.${iM}"













croncheck() {


#1 cmdline aka whole string after time
#2 optional time?


if [ -z "$1" ]; then echo "no job passed"; return 1; fi
if ! crontab -l &>/dev/null; then echo "crontab -l issue"; return 1; fi

jobsmatch=$(crontab -l | cut -d' ' -f6- | grep "$1" | wc -l)



if [ "$jobsmatch" -eq 0 ]; then
    echo "no-matching-jobs: $1 $jobsmatch"
    return 2
fi


echo "jobs-found: $jobsmatch"
if [ "$jobsmatch" -gt 1 ]; then
    echo "many-matching-jobs: $1 $jobsmatch"
    return 2
fi


#if crontab -l | grep -q '/etc/custom/tasks.sh'; then
if crontab -l | grep -q "$1"; then #if crontab -l | grep -q "$1$"; then
    echo "jobfound: "
    #echo "allmatch"
    #crontab -l | grep "$1"
else
    echo "jobnotfound: $1"
    #return 1
fi



return 0



	    if crontab -l | grep -q '/etc/custom/tasks.sh'; then
    		$ecmd "tasks.sh is already in crontab -l"
    		crontab -l | grep '/etc/custom/tasks.sh' > /dev/console
    	else




            $ecmd "adding crontab tasks.sh"
	    	echo "59 05 * * 1 /etc/custom/tasks.sh" > /tmp/crontab.new
	    	if [ -f /etc/crontabs/root ]; then
	    		$ecmd "Existing crontabs.... migrating"
	    		cat /etc/crontabs/root >> /tmp/crontab.new
	 	    fi
		    cat /tmp/crontab.new > /etc/crontabs/root






        fi


	    #$ecmd "Tasks foundations in place"; sleep 1


#$ecmd "no /etc/custom/tasks"; sleep ${RCSLEEP:-0}
}

#59 05 * * 1 /etc/custom/tasks.sh





croninsertline() {

$ecmd "adding crontab tasks.sh"
echo "${*}" > /tmp/crontab.new
if [ -f /etc/crontabs/root ]; then
	$ecmd "Existing crontabs.... migrating"
	cat /etc/crontabs/root >> /tmp/crontab.new
fi
cat /tmp/crontab.new > /etc/crontabs/root
}







cronlineadd() {
paramC=$(echo  "${1}" | wc -w) #AS!$(echo ${1} | wc -w) #AST!$(echo -e ${1} | wc -w) #NOPEwCALLnoINCOM$(echo  "${*}" | wc -w)
#echo "params: $paramC"

if [ "$paramC" -lt 6 ]; then
    echo "noenoughvalues: $paramC"
    return 1
fi

if crontab -l | grep -x -F -q "${*}"; then
    echo "cronjob: ${*} [present]"
    return 0
else
    echo "cronjob: ${*} [add]"
    croninsertline "${*}"


    return 0
fi
return 0
}















cronjobcnt=$(crontab -l)



#NOPE fgrep -r '/etc/crontabs/root'
echo "check upgrade lists for crontab $(fgrep -r '/etc/crontabs' /lib/upgrade/keep.d/ /etc/sysupgrade.conf)"


SRF="59 12 * * 1 /etc/custom/tasks.sh"

cat /etc/crontabs/root
#sed -i "s!^"${SRF}"\$!\#${SRF}!g" /etc/crontabs/root #sed -i "!${SRF}!d" /etc/crontabs/root
sed -i "s!^\"${SRF}\"\$!\#${SRF}!g" /etc/crontabs/root #sed -i "!${SRF}!d" /etc/crontabs/root
cat /etc/crontabs/root



exit 0


#croncheck '/etc/custom/tasks.sh'
#cronlinerem "59 05 * * 1 /etc/custom/tasks.sh" #w echo "" | wc #NOPE cronlineadd 59 05 * * 1 /etc/custom/tasks.sh
#cronlinerem "59 12 * * 1 /etc/custom/tasks.sh" #w echo "" | wc #NOPE cronlineadd 59 05 * * 1 /etc/custom/tasks.sh


cronlineadd "59 05 * * 1 /etc/custom/tasks.sh daily" #w echo "" | wc #NOPE cronlineadd 59 05 * * 1 /etc/custom/tasks.sh
#cronlineadd "59 12 * * 1 /etc/custom/tasks.sh" #w echo "" | wc #NOPE cronlineadd 59 05 * * 1 /etc/custom/tasks.sh




exit 0



case "$sACTION" in
    init) :
    if ! isok ff "${ffpfx}.init"; then
        echo "running init"; #sleep 2 #echo "${ffpfx}.init"




        touch "${ffpfx}.init"
    else
        echo "already init"; sleep 2
    fi
    ;;


    daily) :
    ;;


    hourly) :
    ;;

esac









exit 0

#(crontab -u mobman -l 2>/dev/null; echo "*/5 * * * * perl /home/mobman/test.pl") | crontab -u mobman




#I have also tried to escape the '$' and the braces also.
$ sed "/\${PATTERN}/s!^!#!" cron.backup > newCron.sample
$ sed "/\$\{PATTERN\}/s!^!#!" cron.backup > newCron.sample
#None of the above is working. but if I use the following code, its working absolutely fine
#$ sed "/\/mypath\/scripts/s!^!#!" cron.backup > newCron.sample











#!/bin/sh
#FROM
#00 23 * * 3 /users/notes01/scripts/sad/util/notes_cmd_maint.ksh
##################################################################
#TO ------------------------------------------
#00 23 * * * ksh -c '. $HOME/.kshrc;$PRCCOM/sys_purge_fic.ksh' > /tmp/sys_purge_fic_notes01.log 2>&1
#
#15 23 * * 4 /users/notes01/scripts/sad/util/notes_cmd_maint.ksh




cp crontab crontab.old




awk '{ if ( $0 ~ /notes_cmd_maint.ksh/ ) 
	{ print "15 23 * * 4 " $6 } 
       else { print $0 } 
     }' crontab.old > crontab


awk '{ if ( $0 ~ /notes_cmd_maint.ksh/ ) 
	{ gsub( /notes01/, "notes02", $6); print "15 23 * * 4 " $6 } 
       else { print $0 } 
     }' crontab.old > crontab




exit 0


























##########################################3 interest get line number for grep in general but too fancy for here (broken)
cronlinerem() {
paramC=$(echo  "${1}" | wc -w) #AS!$(echo ${1} | wc -w) #AST!$(echo -e ${1} | wc -w) #NOPEwCALLnoINCOM$(echo  "${*}" | wc -w)
#echo "params: $paramC"

if [ "$paramC" -lt 6 ]; then
    echo "noenoughvalues: $paramC"
    return 1
fi

#if crontab -l | grep -x -F -q "${*}"; then #NOPE if crontab -l | grep -x -F -q "${*}$"; then
if crontab -l | grep -x -F -q "${*}"; then #NOPE if crontab -l | grep -x -F -q "${*}$"; then

	realC=$(echo "${*}" | wc -c)

	#for MATCH in $(crontab -l | grep -x -F "${*}"); do
	crontab -l | grep -x -F "${*}" | while read MATCH; do
		
		thisC=$(echo "$MATCH" | wc -c)
		echo "MATCH: $MATCH"
		echo "realC: $realC"
		echo "thisC: $thisC"
	
	done

    cronLno=$(grep -n -F "${1}" /etc/crontabs/root | cut -d':' -f1)
    echo "cronjob: ${*} [present]"
    echo "cronjobline: ${cronLno}"

    #echo "sed -i \"!${1}!d\" /etc/crontabs/root"
    #sed -i "!${1}!d" /etc/crontabs/root
    return 0





else
    echo "cronjob: ${*} [notpresent]" #croninsertline "${*}"
    return 0
fi
return 0
}











logF="/SPAZ"
$ecmd "STARTTEST3-with-logF" -L
sleep 2


$ecmd "STARTTEST5-with-logF-onprevious" -L
sleep 2









isok() {

FN="isok"; #ecmd "$FN ${*}" 2 5

if [ -z "$1" ]; then $ecmd "param 1 [missing]" && return 1; fi
if [ -z "$1" ]; then $ecmd "param 2 [missing]" && return 1; fi

#$ecmd "$FN: ${*}"; sleep 2

case $1 in
	link)
		:
	;;
	file)
		:
	;;
	flagfile)
		if [ ! -f "$2" ]; then return 0; else return 1; fi;
	;;
	dir) if [ ! -d "$2" ]; then return 1; fi; ;;
	*)
		echo "$FN invalid case $1"; return 1
	;;
esac

return 0
}










rundir() {

#0.5 maybe a name of callerorcomment
#1 dir
#2 optional findstr

FN="rundir";
#$ecmd "$FN: ${*}"; #sleep 2

if [ -z "$1" ]; then $ecmd "param 1 [missing]" && return 1; fi
if [ ! -z "$2" ]; then
	: #$ecmd ">>> recieved findstr: $2"; #sleep 3;
fi


if [ ! -z "$2" ]; then

	jobnum="`find $1/$2 2>/dev/null | wc -l`"
	if [ $jobnum -gt 0 ]; then
		$ecmd "got jobs $jobnum"
		for z in `find $1/$2 2>/dev/null`; do
			if [ ! -x "$z" ]; then
				$emcd "script: $z [non-executable]"
			else

				$ecmd "################# running: $z"

				if [ ! -d "`dirname $z`/output/`basename $z`" ]; then
					$ecmd "Creating output dir `dirname $z`/output/`basename $z`"
					mkdir -p "`dirname $z`/output/`basename $z`"
				fi


				cmdoutputfile="`dirname $z`/output/`basename $z`/$DF.output"
				sh $z > /tmp/cmdout
				if [ "$retval" -eq 0 ]; then
					outlines="`cat /tmp/cmdout | wc -l`"
					$ecmd "success > $cmdoutputfile:$outlines"
					mv /tmp/cmdout $cmdoutputfile
				else
					$ecmd "fail  > $cmdoutputfile.failed:$outlines"
					mv /tmp/cmdout $cmdoutputfile.failed
				fi
				#sh $z
			fi
			sleep 2
		done

	else
		$ecmd "find $1/$2 2>/dev/null [zero-matches]"
	fi

else

	jobnum=`ls -l $1 | grep -v '^d' | wc -l`
	if [ $jobnum -gt 0 ]; then

		$ecmd "$1 has $jobnum scripts"; sleep 1

		for z in $1/*; do
			#echo "Z: $z"
			if [ ! -x "$z" ]; then
				$emcd "script: $z [non-executable]"
			else
				$ecmd "################# running: $z"

				if [ ! -d "`dirname $z`/output/`basename $z`" ]; then
					$ecmd "Creating output dir `dirname $z`/output/`basename $z`"
					mkdir -p "`dirname $z`/output/`basename $z`"
				fi
				cmdoutputfile="`dirname $z`/output/`basename $z`/$DF.output"
				sh $z > /tmp/cmdout
				if [ "$retval" -eq 0 ]; then
					outlines="`cat /tmp/cmdout | wc -l`"
					$ecmd "success > $cmdoutputfile:$outlines"
					mv /tmp/cmdout $cmdoutputfile
				else
					$ecmd "fail  > $cmdoutputfile.failed:$outlines"
					mv /tmp/cmdout $cmdoutputfile.failed
				fi
			fi
			sleep 1
		done

	else
		$ecmd "$1 has $jobnum scripts"; sleep 1
	fi
fi

}



runtask() {

################## calls rundir seperate because furutre complex flagflile switches and echo comments etc
#1 comment
#2 dir
#3 flagfile
#4 optional findstr

FN="runtask"

if [ -z "$2" ]; then
	$ecmd "$FN: param2: dir [missing-or-z]" && return 2;
fi
if [ ! -z "$4" ]; then
	:	#$ecmd "findstr passed: $4" && sleep 2;
fi

if isok dir "$2"; then dirvalid="[ok]"; fi
if isok flagfile "$3"; then flagclear="[ok]"; fi


$ecmd "#########################################"
$ecmd "$FN: ${*}";
$ecmd "      comment: $1"
$ecmd "          dir: $2 $dirvalid"
$ecmd "     flagfile: $3 $flagclear"
$ecmd "      findstr: $4 (optional)"

if [ -z "$dirvalid" ]; then
	$ecmd "nodir: $2" && return 1
fi

if [ -z "$flagclear" ]; then
	$ecmd "flag exists: $3" && return 1
fi

$ecmd "$FN: rundir $2 $4" #DBGONLY
rundir "$2" $4

$ecmd "DBG: touch $2"
touch $2


#$ecmd "touch $fP/$Dd"
#touch "$fP/$Dd"
$ecmd "touch $3"
touch "$3"

}






$ecmd "######################################################";
$ecmd " tasks directory: $taskD"
$ecmd "     flag-prefix: $fP"
$ecmd "             now: $now"
$ecmd "           today: $today"
$ecmd "             day: $Dd"
$ecmd "            hour: $DH"
$ecmd "          minute: $DM"
sleep 2




##################3 testing clear flags
#$ecmd "DBG: rm $fP/$Dd 2>/dev/null"; sleep 2
#$ecmd "DBG: rm $fP/$DH 2>/dev/null"; sleep 2
#rm $fP/$Dd 2>/dev/null
#rm $fP/$DH 2>/dev/null








#@@@!!! fix check for flagfile and return first...



########################################################## HOURLY
Dh=`date +%Y%m%d%H`

logger -t $0 "run-tasks-called: dstamp:$DF dir:$taskD"

$ecmd "DBG: runtask hourly all $taskDhourly $fP/$Dh "; sleep 3
runtask "runtaskhourly *" "$taskDhourly" "$fP/$Dh" ""; sleep 3
#$ecmd "DBG: runtask hourly all $taskDhourly $fP/$Dh *"; sleep 3
#runtask "runtaskhourly *" "$taskDhourly" "$fP/$Dh" "*"; sleep 3





skeel() {
########################################################## DAILY
logger -t $0 "run-tasks-called: dstamp:$DF dir:$taskD"
Dd=`date +%Y%m%d` #NOTE THIS IS A FIX FF was /05 -> /20201105 !!! needs moving higher many otherfixesetc.
$ecmd "DBG: runtask dailyONLYmatching-netstat* $taskDdaily $fP/$Dd netstat*"; sleep 3
runtask "dailyONLYmatching-netstat*" "$taskDdaily" "$fP/$Dd" "netstat*"; sleep 3
}







##########################################################


exit 0

#########################################################################
#runtask "daily" "$taskDdaily" "$fP/$Dd"
#runtask "HOURLY" "$taskDhourly" "$fP/$DH"
#########################################################################
#runtask "ONCEONTHISDATE" "$taskDtoday" "$fP/$today" #thisdate
#########################################################################
#runtask "dailyONLYmatching" "$taskDdaily" "$fP/$Dd" "ifconfig"



#$ecmd "DBG: runtask dailyONLYmatching*-netstat* $taskDdaily $fP/$Dd *-netstat*"; sleep 3
#runtask "dailyONLYmatching*-netstat*" "$taskDdaily" "$fP/$Dd" "*-netstat*"; sleep 3
#$ecmd "DBG: runtask dailyONLYmatching-netstat* $taskDdaily $fP/$Dd netstat*"; sleep 3
#runtask "dailyONLYmatching-netstat*" "$taskDdaily" "$fP/$Dd" "netstat*"; sleep 3

#####$ecmd "DBG: SOMERANDOMSTRINGS runtask randomtestfulldirhourly $taskDhourly $fP/$Dd *"
#$ecmd "DBG: SOMERANDOMSTRINGS runtask randomtestfulldirhourly $taskDhourly $fP/$DH *"
#sleep 3
#####runtask randomtestfulldirhourly "$taskDhourly" "$fP/$DH" *
#runtask randomtestfulldirhourly "$taskDhourly" "$fP/$DH" *
#sleep 3





